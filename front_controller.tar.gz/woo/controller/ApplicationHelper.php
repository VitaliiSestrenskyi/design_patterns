<?php

namespace woo\controller;

use League\Flysystem\Exception;

class ApplicationHelper
{
    private static $instance;
    private $config = "/tmp/data/woo_options.xml";

    private function __construct(){}

    public static function instance()
    {
        if( ! self::$instance )
            self::$instance = new self();

        return self::$instance;
    }

    public function init()
    {
        $dsn = \woo\base\ApplicationRegistry::getDSN();
        if( !is_null($dsn) )
            return;

        $this->getOptions();
    }

    private function getOptions()
    {
        $this->ensure( file_exists($this->config), "Файл конфигурации не найден" );
        $options = @SimpleXml_load_file( $this->config );
        print  get_class( $options );
        $dsn = (string)$options->dsn;
        $this->ensure( $options instanceof \SimpleXMLElement, "Файл конфигурации запорчен");
        $this->ensure( $dsn, "DSN не найден");
        \woo\base\ApplicationRegistry::setDSN( $dsn );
    }

    private function ensure( $expr, $message )
    {
        if( !$expr )
            throw new Exception($message);
    }
}

